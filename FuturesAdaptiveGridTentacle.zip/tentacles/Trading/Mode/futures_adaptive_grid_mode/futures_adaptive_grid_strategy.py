import asyncio
from octobot_trading.strategies.strategy import Strategy
import octobot_trading.enums as enums

class FuturesAdaptiveGridStrategy(Strategy):
    def init_user_inputs(self, inputs: dict) -> None:
        self.grid_number = self.UI.user_input("grid-number", enums.UserInputTypes.INT, 20, inputs, min_val=1, title="Nombre de paliers de la grille")
        self.order_amount = self.UI.user_input("order-amount", enums.UserInputTypes.FLOAT, 10, inputs, min_val=0.0001, title="Montant par ordre (USDT)")
        self.max_open_orders = self.UI.user_input("max-open-orders", enums.UserInputTypes.INT, 20, inputs, min_val=1, title="Nombre max d'ordres")
        self.atr_period = self.UI.user_input("atr-period", enums.UserInputTypes.INT, 14, inputs, min_val=1, title="Période ATR")
        self.atr_multiplier = self.UI.user_input("atr-multiplier", enums.UserInputTypes.FLOAT, 2.0, inputs, min_val=0.1, title="Multiplicateur ATR")
        self.adaptation_interval = self.UI.user_input("adaptation-interval-minutes", enums.UserInputTypes.INT, 60, inputs, min_val=1, title="Intervalle adaptation (min)") * 60
        self.take_profit = self.UI.user_input("take-profit", enums.UserInputTypes.FLOAT, 1.5, inputs, min_val=0.0, title="Take-profit (%)")
        self.stop_loss = self.UI.user_input("stop-loss", enums.UserInputTypes.FLOAT, 1.0, inputs, min_val=0.0, title="Stop-loss (%)")
        self.order_type = self.UI.user_input("order-type", enums.UserInputTypes.LIST, "limit", inputs, options=["limit", "market"], title="Type d'ordre")

    async def initialize_impl(self):
        # Use default values if init_user_inputs didn't run
        await self.update_grid_bounds()

    async def update_grid_bounds(self):
        market_data = self.get_market_data()
        atr = market_data.get_atr(self.atr_period)
        current_price = market_data.get_current_price()
        upper_bound = current_price + atr * self.atr_multiplier
        lower_bound = current_price - atr * self.atr_multiplier
        self.logger.info(f"New grid bounds: {lower_bound} - {upper_bound}")
        # Logic to place or update grid orders goes here

    async def run(self):
        while True:
            await self.update_grid_bounds()
            await asyncio.sleep(self.adaptation_interval)

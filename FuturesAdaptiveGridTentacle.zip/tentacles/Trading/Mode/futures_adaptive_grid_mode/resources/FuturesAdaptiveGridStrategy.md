# Futures Adaptive Grid Strategy

Cette stratégie de trading en grille pour contrats Futures BTC/USDT sur KuCoin adapte automatiquement les bornes de la grille  
à la volatilité mesurée par l'Average True Range (ATR).

- **ATR Period** : nombre de bougies pour le calcul ATR  
- **ATR Multiplier** : coefficient pour déterminer l'amplitude de la grille  
- **Intervalle d'adaptation** : fréquence de recalcul des bornes (en minutes)  
- **Take-profit / Stop-loss** : niveaux de prise de profit et limite de perte  

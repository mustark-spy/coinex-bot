from octobot_trading.strategies.strategy import Strategy

class FuturesAdaptiveGridStrategy(Strategy):
    async def initialize_impl(self):
        self.atr_period = self.config.get("atr-period", 14)
        self.atr_multiplier = self.config.get("atr-multiplier", 2.0)
        self.adaptation_interval = self.config.get("adaptation-interval-minutes", 60) * 60
        self.order_amount = self.config["order-amount"]
        await self.update_grid_bounds()

    async def update_grid_bounds(self):
        market_data = self.get_market_data()
        atr = market_data.get_atr(self.atr_period)
        current_price = market_data.get_current_price()
        upper_bound = current_price + atr * self.atr_multiplier
        lower_bound = current_price - atr * self.atr_multiplier
        self.logger.info(f"New grid bounds: {lower_bound} - {upper_bound}")
        # Ici tu ajoutes le code qui replace les ordres selon ces nouvelles limites

    async def run(self):
        while True:
            await self.update_grid_bounds()
            await self.async_sleep(self.adaptation_interval)

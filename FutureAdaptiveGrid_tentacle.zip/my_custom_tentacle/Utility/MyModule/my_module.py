class MyModuleClass:
    """
    Exemple de module utilitaire pour OctoBot.
    Ajoutez ici vos fonctions d'analyse, helpers, etc.
    """
    def __init__(self, config):
        self.config = config

    def helper_function(self, data):
        # Exemple de méthode
        return data

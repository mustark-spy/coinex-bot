from .my_module import MyModuleClass
